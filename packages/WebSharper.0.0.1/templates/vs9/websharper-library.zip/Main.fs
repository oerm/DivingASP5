﻿namespace $safeprojectname$

open IntelliFactory.WebSharper
