using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("$safeprojectname$")]
[assembly: AssemblyDescription("$safeprojectname$")]
#if DEBUG
[assembly: AssemblyConfiguration("Debug")]
#else
[assembly: AssemblyConfiguration("Release")]
#endif
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Web")]
[assembly: AssemblyCopyright("Copyright (c) $username$, $year$")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0")]
// [assembly: AssemblyDelaySign(false)]
// [assembly: AssemblyKeyFile("")]
// [assembly: AssemblyKeyName("")]
