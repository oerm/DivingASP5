namespace $safeprojectname$.Controllers

open System
open System.Web.Mvc
open $safeprojectname$

[<HandleError>]
type HomeController() =
    inherit Controller()

    member this.Index() =
        this.ViewData.["Message"] <- "Welcome to WebSharper / ASP.NET MVC demo application"
        this.View()

[<HandleError>]
type FormletsController() =
    inherit Controller()

    member this.Index() =
        this.View()

[<HandleError>]
type PageletsController(model : AppModel) =
    inherit Controller()

    member this.Items() =
        let viewModel : ViewModel = {Items = model.Items |> Array.ofSeq}
        this.View(viewModel)
